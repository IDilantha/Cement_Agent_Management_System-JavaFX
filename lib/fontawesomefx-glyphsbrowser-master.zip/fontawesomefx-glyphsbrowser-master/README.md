# FontAwesomeFX Glyphsbrowser + Search Bar added 

Without Searching
![search](https://user-images.githubusercontent.com/20374208/32386681-b2c17dc6-c0ca-11e7-9a68-a42155703c18.png)

When Searching
![we](https://user-images.githubusercontent.com/20374208/32386684-b472873c-c0ca-11e7-8f9d-723e77eac2e7.png)

[SearchBar + fontawesomefx-glyphsbrowser-1.3.0.zip](https://github.com/Jerady/fontawesomefx-glyphsbrowser/files/1441864/SearchBar.fontawesomefx-glyphsbrowser-1.3.0.zip)

## Download FontAwesomeFX 8.15
[from Bintray](https://bintray.com/jerady/maven/FontAwesomeFX/8.15/view)
